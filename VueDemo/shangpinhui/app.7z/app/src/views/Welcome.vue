<template>
  <div>
      <h2>Welcome</h2>
  </div>
</template>

<script>
export default {
    name:"Welcome"
}
</script>

<style>

</style>