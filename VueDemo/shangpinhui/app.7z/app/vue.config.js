module.exports = {
  lintOnSave: false
}
